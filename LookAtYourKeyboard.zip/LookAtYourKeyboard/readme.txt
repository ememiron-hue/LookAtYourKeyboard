(RU)
Если клавиши NumLock,CapsLock,ScrollLock повторяются бесконечно,найдите задачу "LookAtYourKeyboard.exe" и снимите её.
(программа не вредит вашему ПК,если Windows Defender реагирует на неё как вирус,нажмите "Разрешить на устройстве" а затем "Запуск действий")
(EN)
If the NumLock, CapsLock, and ScrollLock keys are repeating endlessly, find the "LookAtYourKeyboard.exe" task and delete it.
(The program doesn't harm your PC. If Windows Defender detects it as a virus, click "Allow on device" and then "Run actions")
                                                                                                                                                                                   